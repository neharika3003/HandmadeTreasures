const express = require('express');
const Order = require('../models/Order');
const { isAuthenticated, isAdmin } = require('../middleware/auth'); // Assuming you have an auth middleware
const router = express.Router();

// Create a new order
router.post('/', isAuthenticated, async (req, res) => {
    const { items, totalAmount } = req.body;

    // Create a new order
    const order = new Order({
        buyerId: req.user._id, // Assuming you have user data in req.user after authentication
        items,
        totalAmount,
    });

    try {
        await order.save();
        res.status(201).json({ message: 'Order placed successfully', order });
    } catch (err) {
        res.status(500).json({ message: 'Error placing order', error: err.message });
    }
});

// Get all orders for admin
router.get('/', isAdmin, async (req, res) => {
    try {
        const orders = await Order.find().populate('buyerId').populate('items.productId');
        res.render('admin/orders', { orders });
    } catch (err) {
        res.status(500).json({ message: 'Error fetching orders', error: err.message });
    }
});

// Update order status (for admin)
router.post('/update/:id', isAdmin, async (req, res) => {
    const { status } = req.body;
    try {
        const order = await Order.findByIdAndUpdate(req.params.id, { status }, { new: true });
        res.status(200).json({ message: 'Order updated successfully', order });
    } catch (err) {
        res.status(500).json({ message: 'Error updating order', error: err.message });
    }
});

module.exports = router;
