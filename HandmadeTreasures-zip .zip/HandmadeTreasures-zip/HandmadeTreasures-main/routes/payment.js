const express = require('express');
const router = express.Router();

// Render payment page
router.get('/payment', (req, res) => {
    // Get total from query parameter or cart
    const total = req.query.total || (req.session.cart ? req.session.cart.total : 0);
    res.render('payment', { total });
});

// Handle successful payment
router.get('/orders/success', (req, res) => {
    // Clear cart after successful payment
    req.session.cart = null;
    
    res.render('order-success', {
        message: 'Your order has been placed successfully!'
    });
});

module.exports = router; 