const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const User = require('../models/User');

// Middleware to check if user is admin
const isAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        return next();
    }
    return res.status(403).send('Access denied.');
};

// Get all products (Admin)
router.get('/products', isAdmin, async (req, res) => {
    const products = await Product.find();
    res.render('admin/products', { products });
});

// Add new product (Admin)
router.post('/products/add', isAdmin, async (req, res) => {
    const { title, description, image, price, category } = req.body;
    const newProduct = new Product({ title, description, image, price, category });
    await newProduct.save();
    res.redirect('/admin/products');
});

// Edit product (Admin)
router.post('/products/edit/:id', isAdmin, async (req, res) => {
    const { title, description, image, price, category } = req.body;
    await Product.findByIdAndUpdate(req.params.id, { title, description, image, price, category });
    res.redirect('/admin/products');
});

// Delete product (Admin)
router.post('/products/delete/:id', isAdmin, async (req, res) => {
    await Product.findByIdAndDelete(req.params.id);
    res.redirect('/admin/products');
});

module.exports = router;
