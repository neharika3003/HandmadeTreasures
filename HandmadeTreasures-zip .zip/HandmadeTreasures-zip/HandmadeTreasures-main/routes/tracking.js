const express = require('express');
const router = express.Router();

router.get('/track-order', (req, res) => {
    res.render('track-order');
});

module.exports = router; 