const express = require('express');
const User = require('../models/User');
const Review = require('../models/Review');
const { isAuthenticated } = require('../middleware/auth'); // Assuming you have an auth middleware
const router = express.Router();

// Get user profile
router.get('/profile', isAuthenticated, async (req, res) => {
    try {
        const user = await User.findById(req.user._id).populate('reviews');
        res.render('user/profile', { user });
    } catch (err) {
        res.status(500).json({ message: 'Error fetching user profile', error: err.message });
    }
});

// Update user profile
router.post('/profile', isAuthenticated, async (req, res) => {
    const { name, email, bio } = req.body;
    try {
        await User.findByIdAndUpdate(req.user._id, { name, email, bio });
        res.redirect('/user/profile'); // Redirect to profile page
    } catch (err) {
        res.status(500).json({ message: 'Error updating user profile', error: err.message });
    }
});

// Submit a review
router.post('/review', isAuthenticated, async (req, res) => {
    const { productId, rating, comment } = req.body;
    const review = new Review({
        userId: req.user._id,
        productId,
        rating,
        comment,
    });

    try {
        await review.save();
        // Optionally, add the review to the user's reviews array
        await User.findByIdAndUpdate(req.user._id, { $push: { reviews: review._id } });
        res.redirect(`/products/product/${productId}`); // Redirect to product page
    } catch (err) {
        res.status(500).json({ message: 'Error submitting review', error: err.message });
    }
});

module.exports = router;
